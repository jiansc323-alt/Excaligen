#!/usr/bin/env python3
"""
skeleton-to-file.py — ExcalidrawElementSkeleton[] → .excalidraw 文件转换器

用途: 将 LLM 生成的 ExcalidrawElementSkeleton JSON 数组，补全为 Obsidian Excalidraw
      插件可直接打开的 .excalidraw 文件。

输入方式:
  1. 从文件读取:  python skeleton-to-file.py input.json
  2. 从 stdin 读取: echo '[...]' | python skeleton-to-file.py
  3. 指定输出路径: python skeleton-to-file.py input.json -o output.excalidraw

依赖: 纯 Python 标准库，无需安装任何第三方包。
"""

import json
import sys
import os
import random
import string
import argparse
from datetime import datetime


# ─────────────────────────────────────────────────────────────────────
# ID 生成
# ─────────────────────────────────────────────────────────────────────

def generate_id():
    """生成 Excalidraw 元素 ID (20位随机字母数字)"""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choices(chars, k=20))


def generate_seed():
    """生成随机种子 (用于手绘风格的抖动)"""
    return random.randint(1, 2**31 - 1)


# ─────────────────────────────────────────────────────────────────────
# 元素补全
# ─────────────────────────────────────────────────────────────────────

def compute_text_dimensions(text, font_size=20):
    """
    简单估算文本元素的宽高。
    中文字符按 font_size 宽度估算，英文/数字按 0.6 * font_size。
    """
    char_count = len(text)
    # 粗略计算: 中文字符约占 1.0 字宽，英文约占 0.6
    cn_count = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    en_count = char_count - cn_count
    width = cn_count * font_size * 1.0 + en_count * font_size * 0.6 + 20
    height = font_size * 1.5 + 10
    return round(width), round(height)


def enrich_element(elem):
    """
    将 ExcalidrawElementSkeleton 补全为标准 ExcalidrawElement。
    添加 id, version, versionNonce, seed 等必需字段。
    """
    enriched = dict(elem)  # 浅拷贝
    
    # 保留用户自定义 id，否则生成
    if 'id' not in enriched:
        enriched['id'] = generate_id()
    
    elem_type = enriched.get('type', 'rectangle')
    
    # 版本与随机种子
    enriched['version'] = 1
    enriched['versionNonce'] = random.randint(1, 2**31 - 1)
    enriched['seed'] = generate_seed()
    enriched['isDeleted'] = False
    
    # 根据类型补全
    if elem_type == 'text':
        enriched.setdefault('fontSize', 20)
        enriched.setdefault('fontFamily', 1)
        enriched.setdefault('textAlign', 'left')
        enriched.setdefault('verticalAlign', 'top')
        if 'width' not in enriched or 'height' not in enriched:
            w, h = compute_text_dimensions(
                enriched.get('text', ''),
                enriched.get('fontSize', 20)
            )
            enriched.setdefault('width', w)
            enriched.setdefault('height', h)
        enriched.setdefault('strokeColor', '#1e1e1e')
        enriched.setdefault('backgroundColor', 'transparent')
    
    elif elem_type in ('rectangle', 'ellipse', 'diamond'):
        enriched.setdefault('width', 160)
        enriched.setdefault('height', 80)
        enriched.setdefault('strokeColor', '#1e1e1e')
        enriched.setdefault('backgroundColor', 'transparent')
        enriched.setdefault('fillStyle', 'solid')
        enriched.setdefault('strokeWidth', 2)
        enriched.setdefault('roughness', 0)
        enriched.setdefault('opacity', 100)
        enriched.setdefault('roundness', elem_type == 'rectangle' and {'type': 3} or None)
        # 去掉 None 值
        enriched = {k: v for k, v in enriched.items() if v is not None}
        
        # Label is handled later by split_labeled_containers()
        # Keep label info as a private field for now
    
    elif elem_type == 'arrow':
        enriched.setdefault('width', 100)
        enriched.setdefault('height', 0)
        enriched.setdefault('strokeColor', '#1e1e1e')
        enriched.setdefault('strokeWidth', 2)
        enriched.setdefault('roughness', 0)
        enriched.setdefault('opacity', 100)
        enriched.setdefault('endArrowhead', 'arrow')
        
        # 处理绑定信息
        if 'start' in enriched:
            start_info = enriched.pop('start')
            enriched['startBinding'] = build_binding(start_info, enriched)
        else:
            enriched['startBinding'] = None
        
        if 'end' in enriched:
            end_info = enriched.pop('end')
            enriched['endBinding'] = build_binding(end_info, enriched)
        else:
            enriched['endBinding'] = None
        
        # Arrow label handled later by split_labeled_containers()
        
        # 生成 points (基于 x, y, width, height)
        enriched['points'] = [[0, 0], [enriched.get('width', 100), enriched.get('height', 0)]]
    
    elif elem_type == 'line':
        enriched.setdefault('width', 100)
        enriched.setdefault('height', 0)
        enriched.setdefault('strokeColor', '#1e1e1e')
        enriched.setdefault('strokeWidth', 2)
        enriched.setdefault('roughness', 0)
        enriched.setdefault('opacity', 100)
        enriched['points'] = [[0, 0], [enriched.get('width', 100), enriched.get('height', 0)]]
    
    elif elem_type == 'frame':
        enriched.setdefault('name', 'Frame')
        if 'children' in enriched:
            enriched['frameRendering'] = {'enabled': True}
    
    elif elem_type == 'freedraw':
        enriched.setdefault('strokeColor', '#1e1e1e')
        enriched.setdefault('strokeWidth', 2)
        enriched.setdefault('roughness', 0)
        enriched.setdefault('opacity', 100)
        enriched.setdefault('points', [[0, 0]])
    
    elif elem_type == 'image':
        enriched.setdefault('width', 200)
        enriched.setdefault('height', 200)
    
    # 通用默认值
    enriched.setdefault('angle', 0)
    enriched.setdefault('strokeColor', '#1e1e1e')
    enriched.setdefault('backgroundColor', 'transparent')
    enriched.setdefault('fillStyle', 'solid')
    enriched.setdefault('strokeWidth', 2)
    enriched.setdefault('roughness', 0)
    enriched.setdefault('opacity', 100)
    enriched.setdefault('groupIds', [])
    enriched.setdefault('frameId', None)
    enriched.setdefault('link', None)
    enriched.setdefault('locked', False)
    
    # 容器类型需要 containerId (only for text elements or child elements)
    enriched.setdefault('containerId', None)
    
    # Label is preserved for split_labeled_containers() to handle
    # (will be removed there)
    
    return enriched


def build_binding(bind_info, parent_element):
    """
    将 Skeleton 的绑定信息转换为 Excalidraw 的 binding 格式。
    
    Skeleton 格式:
      { "type": "rectangle" }  或  { "id": "rect-1" }  或  null
    
    转换后:
      { "elementId": "...", "focus": 0, "gap": 5 }
      或 null
    """
    if bind_info is None:
        return None
    
    binding = {
        "focus": 0,
        "gap": 5
    }
    
    if isinstance(bind_info, dict):
        if 'id' in bind_info:
            binding['elementId'] = bind_info['id']
        elif 'type' in bind_info:
            # Skeleton 中只指定了 type，没有具体 id
            # 保留为 null，运行时由 Excalidraw 自动匹配
            binding['elementId'] = None
    
    return binding


# ─────────────────────────────────────────────────────────────────────
# 标签容器拆分 (Obsidian Excalidraw 兼容)
# ─────────────────────────────────────────────────────────────────────

def split_labeled_containers(elements):
    """
    将带 label 的容器/箭头元素拆分为主体 + 独立文本元素。
    
    Obsidian Excalidraw 插件使用 boundElements + containerId 绑定方式:
    - 主体: boundElements = [{type: "text", id: "text-id"}]
    - 文本: containerId = "container-id"
    """
    result = []
    for elem in elements:
        label = elem.pop('label', None) if isinstance(elem, dict) else None
        elem_type = elem.get('type', '')
        
        if label and isinstance(label, dict) and elem_type in ('rectangle', 'ellipse', 'diamond', 'arrow'):
            container_id = elem.get('id', '')
            text_id = generate_id()
            
            # 主体: 添加 boundElements, 清除直接 text 字段
            elem['boundElements'] = [{"type": "text", "id": text_id}]
            elem.pop('text', None)
            elem.pop('originalText', None)
            elem.pop('containerId', None)
            result.append(elem)
            
            # 文本元素: 绑定到主体
            if elem_type == 'arrow':
                # 箭头标签居中于箭头
                tx = elem.get('x', 0) + elem.get('width', 100) / 2
                ty = elem.get('y', 0) - 15
                tw = elem.get('width', 100)
                th = 30
            else:
                # 容器标签居中于容器
                tx = elem.get('x', 0) + elem.get('width', 100) / 2
                ty = elem.get('y', 0) + elem.get('height', 50) / 2
                tw = elem.get('width', 100) - 20
                th = elem.get('height', 50) - 10
            
            text_elem = {
                "id": text_id,
                "type": "text",
                "containerId": container_id,
                "x": tx,
                "y": ty,
                "width": tw,
                "height": th,
                "text": label.get('text', ''),
                "originalText": label.get('text', ''),
                "fontSize": label.get('fontSize', 20),
                "fontFamily": label.get('fontFamily', 1),
                "textAlign": label.get('textAlign', 'center'),
                "verticalAlign": label.get('verticalAlign', 'middle'),
                "strokeColor": label.get('strokeColor', '#1e1e1e'),
            }
            result.append(enrich_element(text_elem))
        else:
            result.append(elem)
    
    return result


# ─────────────────────────────────────────────────────────────────────
# .excalidraw 文件构建
# ─────────────────────────────────────────────────────────────────────

def build_excalidraw_file(elements):
    """将元素数组包裹为完整的 .excalidraw 文件格式"""
    return {
        "type": "excalidraw",
        "version": 2,
        "source": "https://excalidraw.com",
        "elements": elements,
        "appState": {
            "gridSize": None,
            "viewBackgroundColor": "#ffffff",
        },
        "files": {}
    }


# ─────────────────────────────────────────────────────────────────────
# 转换入口
# ─────────────────────────────────────────────────────────────────────

def convert(input_json, output_path):
    """
    主转换函数。
    
    Args:
        input_json: ExcalidrawElementSkeleton[] (字符串或已解析的 list)
        output_path: .excalidraw 文件输出路径
    
    Returns:
        str: 输出文件路径
    """
    if isinstance(input_json, str):
        data = json.loads(input_json)
    else:
        data = input_json
    
    if not isinstance(data, list):
        raise ValueError("Input must be a JSON array")
    
    # 补全每个元素
    enriched = [enrich_element(elem) for elem in data]
    
    # 拆分带标签的容器为 容器 + 独立文本元素
    enriched = split_labeled_containers(enriched)
    
    # 构建完整文件
    excalidraw_file = build_excalidraw_file(enriched)
    
    # 确保输出目录存在
    output_dir = os.path.dirname(output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
    
    # 写入文件
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(excalidraw_file, f, ensure_ascii=False, indent=2)
    
    return output_path


# ─────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────

def main():
    # Ensure UTF-8 output on Windows
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    
    parser = argparse.ArgumentParser(
        description='ExcalidrawElementSkeleton[] → .excalidraw 文件转换器'
    )
    parser.add_argument(
        'input',
        nargs='?',
        help='输入 JSON 文件路径 (不指定则从 stdin 读取)'
    )
    parser.add_argument(
        '-o', '--output',
        help='输出 .excalidraw 文件路径 (默认: output.excalidraw)'
    )
    
    args = parser.parse_args()
    
    # 读取输入
    if args.input:
        with open(args.input, 'r', encoding='utf-8') as f:
            input_json = f.read()
    else:
        if sys.stdin.isatty():
            print("Error: Please provide an input file path or pipe JSON via stdin", file=sys.stderr)
            sys.exit(1)
        input_json = sys.stdin.read()
    
    # 确定输出路径
    output_path = args.output or 'output.excalidraw'
    if not output_path.endswith('.excalidraw'):
        output_path += '.excalidraw'
    
    # 转换
    result_path = convert(input_json, output_path)
    print(f"[OK] Generated: {result_path}")


if __name__ == '__main__':
    main()
